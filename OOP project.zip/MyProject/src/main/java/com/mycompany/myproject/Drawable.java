package com.mycompany.myproject;

public interface Drawable {
    String howToDraw();
}
