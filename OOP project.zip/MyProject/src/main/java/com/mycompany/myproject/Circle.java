package com.mycompany.myproject;

public class Circle extends Shape {
    // variables : 
    
    private double radius;
    
    // constructors : 
    
    public Circle() {
        this.radius = 0.0;
        super.setColor("Black");
    }
    public Circle(double raduis) {
        super.setColor("Black");
        this.radius = raduis;
    }
    public Circle(String color,double raduis) {
        super(color);
        this.radius = raduis;
    }
    
    // methods :

    public double getRaduis() {
        return radius;
    }
    public void setRaduis(double raduis) {
        this.radius = raduis;
    }
    @Override
    public double getArea(){
        return Math.PI * this.radius * this.radius;
    }
    @Override
    public double getPerimeter(){
        return Math.PI * this.radius * 2;
    }
    @Override
    public String toString() {
        return "Circle{ It's color : " + super.getColor() + " radius = " + radius + '}';
    }
    @Override
    public String howToDraw() {
       return "Drawing a circle. It's Area : " + this.getArea();
    }
}
