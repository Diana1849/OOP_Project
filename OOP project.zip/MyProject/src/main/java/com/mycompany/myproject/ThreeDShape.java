package com.mycompany.myproject;

public abstract class ThreeDShape extends Shape {
    // no variables.
    
    // constructors : 
    
    public ThreeDShape(){}
    public ThreeDShape(String color){
        super(color);
    }
    
    // methods :
    
    public abstract double getVolume();
}
