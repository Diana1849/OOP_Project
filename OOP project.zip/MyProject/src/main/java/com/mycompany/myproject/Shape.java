package com.mycompany.myproject;
import java.util.Date;

public abstract class Shape implements Drawable {
    // Variables : 
    
    private Date dateCreated;
    private String color;
    
    // constructors :

    public Shape() {
        this.dateCreated = new Date();
    }

    public Shape(String color) {
        this.dateCreated = new Date();
        this.color = color;
    }
    
    // methods :
    
    // abstracted methods : 
    
    public abstract double getArea();
    public abstract double getPerimeter();
    
    // non abstracted methods : 
    
    public Date getDateCreated() {
        return dateCreated;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
}
